package com.cleansplash.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class SplashAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var isRunning: Boolean = false

        // Prevent repeated clicks in the same app while its UI is settling.
        private val lastClickAt = ConcurrentHashMap<String, Long>()

        private val strongKeywords = listOf(
            "跳过广告",
            "跳过广告",
            "skip ad",
            "skip ads",
            "skip"
        )

        private val closeAdKeywords = listOf(
            "关闭广告",
            "close ad",
            "close ads"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
    }

    override fun onDestroy() {
        isRunning = false
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                val packageName = event.packageName?.toString() ?: return
                if (packageName == applicationContext.packageName) return

                val now = System.currentTimeMillis()
                val previous = lastClickAt[packageName] ?: 0L
                if (now - previous < 1800L) return

                val root = rootInActiveWindow ?: return
                val clicked = findAndClick(root)

                if (clicked) {
                    lastClickAt[packageName] = now
                }
            }
        }
    }

    private fun findAndClick(root: AccessibilityNodeInfo): Boolean {
        val nodes = ArrayDeque<AccessibilityNodeInfo>()
        nodes.add(root)

        while (nodes.isNotEmpty()) {
            val node = nodes.removeFirst()

            val text = buildString {
                node.text?.let { append(it).append(' ') }
                node.contentDescription?.let { append(it) }
            }.trim().lowercase(Locale.ROOT)

            if (text.isNotEmpty() && isStrongSkipText(text)) {
                if (tryClick(node)) return true
            }

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { nodes.add(it) }
            }
        }

        return false
    }

    private fun isStrongSkipText(text: String): Boolean {
        val normalized = text.replace("\\s+".toRegex(), " ").trim()

        if (strongKeywords.any { normalized.contains(it) }) return true
        if (closeAdKeywords.any { normalized.contains(it) }) return true

        // Common Chinese variants that explicitly mean "skip".
        if (normalized.contains("跳过") && normalized.length <= 12) return true

        return false
    }

    private fun tryClick(node: AccessibilityNodeInfo): Boolean {
        if (node.isVisibleToUser) {
            if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }

            // Some ad SDKs put the text on a non-clickable child.
            var parent = node.parent
            repeat(3) {
                if (parent != null) {
                    if (parent.isVisibleToUser &&
                        parent.isClickable &&
                        parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    ) {
                        return true
                    }
                    parent = parent.parent
                }
            }
        }
        return false
    }

    override fun onInterrupt() {
        // Nothing to release: V1 intentionally keeps the service lightweight.
    }
}
