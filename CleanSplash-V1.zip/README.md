# CleanSplash

CleanSplash V1 是一个面向个人测试的轻量级 Android 开屏广告跳过助手。

## V1 目标

- 使用 Android AccessibilityService 监听界面变化。
- 读取当前窗口的无障碍节点。
- 只对明确出现的“跳过广告 / Skip / Skip Ad / 关闭广告”等文字按钮尝试点击。
- 不做持续截图识别。
- 不联网、不上传屏幕内容。
- 对同一个 App 设置短暂冷却，减少重复点击。
- 使用传统 Android View，不引入 Compose，尽量降低 APK 和运行时开销。

## 使用

安装 APK 后：

1. 打开 CleanSplash。
2. 点击“打开无障碍设置”。
3. 在系统无障碍服务中开启“CleanSplash 开屏助手”。
4. 打开一个带开屏广告的 App 测试。

## 注意

不同 App 的广告实现差异很大。V1 只处理能通过 Android 无障碍节点暴露出明确跳过/关闭文字的情况。

本项目目前用于个人设备测试，不包含 Google Play 上架配置。
