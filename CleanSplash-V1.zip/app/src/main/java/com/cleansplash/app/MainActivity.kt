package com.cleansplash.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showUi()
    }

    override fun onResume() {
        super.onResume()
        showUi()
    }

    private fun showUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 72, 48, 48)
            gravity = Gravity.TOP
        }

        val title = TextView(this).apply {
            text = getString(R.string.title)
            textSize = 30f
            setTextColor(getColor(R.color.black))
        }

        val subtitle = TextView(this).apply {
            text = getString(R.string.subtitle)
            textSize = 18f
            setTextColor(getColor(R.color.gray))
            setPadding(0, 12, 0, 36)
        }

        val status = TextView(this).apply {
            text = if (SplashAccessibilityService.isRunning) {
                getString(R.string.status_on)
            } else {
                getString(R.string.status_off)
            }
            textSize = 20f
            setPadding(0, 0, 0, 24)
        }

        val settingsButton = Button(this).apply {
            text = getString(R.string.open_settings)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val hint = TextView(this).apply {
            text = getString(R.string.enable_hint)
            textSize = 15f
            setTextColor(getColor(R.color.gray))
            setPadding(0, 24, 0, 20)
        }

        val note = TextView(this).apply {
            text = getString(R.string.safe_note)
            textSize = 14f
            setTextColor(getColor(R.color.gray))
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(settingsButton)
        root.addView(hint)
        root.addView(note)

        setContentView(root)
    }
}
