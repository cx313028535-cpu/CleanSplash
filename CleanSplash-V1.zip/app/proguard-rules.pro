# CleanSplash V1 intentionally keeps minification off.
